
#ifndef __LCD_H
#define __LCD_H		
#include "main.h"
#include "sys.h"


#define USE_HORIZONTAL

#define LCD_W 128
#define LCD_H 160

#define LCD_Port GPIOA
#define LCD_RS GPIO_PIN_3
//#define LCD_SDI GPIO_PIN_7
#define LCD_SDO GPIO_PIN6
#define LCD_CS GPIO_PIN_4
//#define LCD_CLK GPIO_PIN_5
#define LCD_RESET GPIO_PIN_2
#define LCD_BL GPIO_PIN_1


extern uint16_t  POINT_COLOR;
extern uint16_t  BACK_COLOR;

typedef struct  
{										    
	uint16_t width;
	uint16_t height;
	uint16_t id;
	uint8_t  dir;
	uint16_t	 wramcmd;
	uint16_t  setxcmd;
	uint16_t  setycmd;
}_lcd_dev; 	


extern _lcd_dev lcddev;

void LCD_Init(void); 
void LCD_Clear(uint16_t Color);
void spi_write_byte(uint8_t d);
void LCD_WR_DATA(uint8_t Data);
void LCD_WR_REG(uint8_t Reg);
void LCD_SetCursor(uint16_t Xpos, uint16_t Ypos);
void LCD_SetWindows(uint16_t xStar, uint16_t yStar,uint16_t xEnd,uint16_t yEnd);
void LCD_DrawPoint(uint16_t x,uint16_t y);
void LCD_WriteRAM_Prepare(void);
void LCD_direction(uint8_t direction );
void LCD_WR_DATA_16Bit(uint16_t Data);


#define WHITE         	 0xFFFF
#define BLACK         	 0x0000	  
#define BLUE         	 0x001F  
#define BRED             0XF81F
#define GRED 			 0XFFE0
#define GBLUE			 0X07FF
#define RED           	 0xF800
#define MAGENTA       	 0xF81F
#define GREEN         	 0x07E0
#define CYAN          	 0x7FFF
#define YELLOW        	 0xFFE0
#define BROWN 			 0XBC40
#define BRRED 			 0XFC07
#define GRAY  			 0X8430

#define DARKBLUE      	 0X01CF
#define LIGHTBLUE      	 0X7D7C
#define GRAYBLUE       	 0X5458
 
#define LIGHTGREEN     	 0X841F
#define LGRAY 			 0XC618

#define LGRAYBLUE        0XA651
#define LBBLUE           0X2B12


					  		 
#endif  
	 
	 



